<template>
  <div class="home"></div>
</template>

<script>
export default {

}
</script>

<style scoped>
.home{
    background-image: url(../../assets/img/jsx.jpg);
    height: 100vh;
    background-size: cover;
}

</style>
